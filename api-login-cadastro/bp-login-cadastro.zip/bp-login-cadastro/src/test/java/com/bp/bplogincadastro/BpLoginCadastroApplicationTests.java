package com.bp.bplogincadastro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpLoginCadastroApplicationTests {

	@Test
	void contextLoads() {
	}

}
