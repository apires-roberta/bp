package com.bp.bplogincadastro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BpLoginCadastroApplication {

	public static void main(String[] args) {
		SpringApplication.run(BpLoginCadastroApplication.class, args);
	}

}
