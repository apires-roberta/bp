package bp.logincadastrobcd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginCadastroBcdApplicationTests {

	@Test
	void contextLoads() {
	}

}
